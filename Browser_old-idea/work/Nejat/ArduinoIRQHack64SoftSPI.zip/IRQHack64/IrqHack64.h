#ifndef _IRQHACK64_

#define _IRQHACK64_
#define IRQ 2 
#define EXROM 3
#define NMI 8
#define RESET 9
#define SEL 18

#define DEBUG

#endif
