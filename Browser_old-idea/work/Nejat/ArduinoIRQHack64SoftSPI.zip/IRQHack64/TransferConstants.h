#ifndef _TRANSFERCONSTANTS_

#define _TRANSFERCONSTANTS_

const int addressPins[]={ 14, 15 , 16, 17, 4, 5, 6, 7 }; 

#endif
